prompt Importing table PLATFORM_ROLE...
set feedback off
set define off
insert into PLATFORM_ROLE (ID, ROLENAME, ROLECODE, ROLESTATE, ROLETYPE, ROLENOTE, UPDATETIME, CREATETIME, UPDATEUSER, CREATEUSER, DELFLAG)
values ('b7e182c01034452a92bda2b636456cbc', '��������Ա', 'sadmin', null, 'administrator', null, null, null, null, null, null);

insert into PLATFORM_ROLE (ID, ROLENAME, ROLECODE, ROLESTATE, ROLETYPE, ROLENOTE, UPDATETIME, CREATETIME, UPDATEUSER, CREATEUSER, DELFLAG)
values ('ac39034d11504daca3238dacaaa630f1', 'У����', 'xgly', null, 'commonuser', null, null, null, null, null, null);

insert into PLATFORM_ROLE (ID, ROLENAME, ROLECODE, ROLESTATE, ROLETYPE, ROLENOTE, UPDATETIME, CREATETIME, UPDATEUSER, CREATEUSER, DELFLAG)
values ('58deb2eceabc46e0a9eb7ff7590bb559', '��Ŀ����Ա', 'lmgly', null, 'channeladmin', null, null, null, null, null, null);

prompt Done.
