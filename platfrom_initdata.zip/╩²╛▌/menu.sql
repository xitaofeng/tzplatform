prompt Importing table PLATFORM_MENU...
set feedback off
set define off
insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('593e338f364f49a4950003495aea870b', 'У԰���', '/manage/mobileplatform/campusScenery', '441559faa65f424ea9c8d2ae2dfc5289', 5);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('d89b2c30208f4872826c205b642885f2', '��������', '/manage/mobileplatform/poster/list', '441559faa65f424ea9c8d2ae2dfc5289', 1);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('441559faa65f424ea9c8d2ae2dfc5289', '�ƶ�ƽ̨', '/manage/mobileplatform/poster/list', null, 8);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('001ebe214bf44e64b7a001434fba1892', '�����ʴ�', '/manage/question/list', null, 7);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('0d713e6bff9d420fb046fa45c616d6ea', '�ӿڹ���', '/manage/apiinfo/apilist/listApi', 'f29699ae3afc4a869e04d39e9431af96', 2);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('23c9d1b7ccac4c6c85eee004fde59af1', '��վӦ��', '/manage/app/webapp/list', 'ec7f66ddb6cb4a3f893fcacc37ba0bf8', 1);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('2ea932442feb46649cfea6466fa2e82d', '��Ŀ�б�', '/manage/channel/list', '83263dc07ece492a9d76c34fba98e03b', 2);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('34bb0905f3a44cccb7eed2b85a1aacb9', '�ƶ�Ӧ��', '/manage/app/mobile/list', 'ec7f66ddb6cb4a3f893fcacc37ba0bf8', 2);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('48d4f40a4b294dae9b69c03234fba13d', '�ֵ����', '/manage/syssetting/sysdict/type', 'ed49e1673e7549989d48c9be12b60da5', 4);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('507c3ac53dd94b758b95b801d3b20c1c', 'ϵͳ�û�', '/manage/user/sys', 'a37c1567eb60477a97ed722a7087cc8b', 2);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('58b409a7a1474e0fa92c259f752c75eb', '�ӿ�ͳ��', '/manage/apiinfo/statistics', 'f29699ae3afc4a869e04d39e9431af96', 3);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('5e070a7e26d944ad860e4ce381c7979d', '��ɫ����', '/manage/syssetting/role', 'ed49e1673e7549989d48c9be12b60da5', 3);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('63e272e1354048299dd918c54c42cb59', '�������', '/manage/question/list', '001ebe214bf44e64b7a001434fba1892', 3);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('6475dc227faf46ee815bf3349e73798b', '����������', '/manage/user/reguser/list', 'a37c1567eb60477a97ed722a7087cc8b', 1);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('797ae118eb2a43458e1f3a59abb5a8e1', '�쳣��־', '/manage/syssetting/exceptionlog', 'ed49e1673e7549989d48c9be12b60da5', 2);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('83263dc07ece492a9d76c34fba98e03b', '��Ŀ����', '/manage/channel/view', null, 4);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('a37c1567eb60477a97ed722a7087cc8b', '�û�����', '/manage/user/reguser/list', null, 2);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('c0c57d174de14589a6a9a906533d5beb', '�˵�����', '/manage/syssetting/menu', 'ed49e1673e7549989d48c9be12b60da5', 5);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('c490891ddab543d093ce8011f88c5f05', 'ϵͳ����', '/manage/apiinfo/notice/listnotice', 'f29699ae3afc4a869e04d39e9431af96', 4);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('c6f1c1ea86d2462287db3654a2d40f3c', '������־', '/manage/syssetting/normallog', 'ed49e1673e7549989d48c9be12b60da5', 1);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('d86d573966e041b4baebcacd825e4de8', '�ӿ����͹���', '/manage/apiinfo/apitype', 'f29699ae3afc4a869e04d39e9431af96', 1);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('e412e6e9f37d49bd96511b59a55a1d00', '��ĿԤ��', '/manage/channel/view', '83263dc07ece492a9d76c34fba98e03b', 1);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('ec7f66ddb6cb4a3f893fcacc37ba0bf8', 'Ӧ������', '/manage/app/webapp/list', null, 2);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('ed49e1673e7549989d48c9be12b60da5', 'ϵͳ����', '/manage/syssetting/normallog', null, 6);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('f29699ae3afc4a869e04d39e9431af96', '�ӿڹ���', '/manage/apiinfo/apitype', null, 3);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('f3e245a0f9894ffaab140b8eb5d115f1', '��ҳ', '/manage/home', null, 1);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('fb1ae9d0395a401c9844666550c78445', '��Ŀ����', '/manage/channel/content/listContent', '83263dc07ece492a9d76c34fba98e03b', 3);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('fd65ba4d563b44289a6eb947646b0065', 'Ӧ��ͳ��', '/manage/app/count', 'ec7f66ddb6cb4a3f893fcacc37ba0bf8', 4);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('15ef172952bf4f7e9c5e7a4e0a7b40b3', 'ʧ������', '/manage/mobileplatform/lostfound/list', '441559faa65f424ea9c8d2ae2dfc5289', 3);

insert into PLATFORM_MENU (ID, MENUNAME, MENUURL, PARENTID, SORT)
values ('f792cb9baa244ffea0d7bd11732c562d', '�������', '/manage/mobileplatform/feedback/list', '441559faa65f424ea9c8d2ae2dfc5289', 2);

prompt Done.
