prompt Importing table PLATFORM_USERS...
set feedback off
set define off
insert into PLATFORM_USERS (ID, NAME, ACCOUNT, PASSWORD, PASSSALT, USERTYPE)
values ('ffd0253b56de4696b4c46b697993e446', 'testuser1', 'testuser1', 'b2fd3e71b353410495a1f29311e93655179b3f95', 'aa21ea190cca4f81bfa6e87d3558fa6b', '0');

insert into PLATFORM_USERS (ID, NAME, ACCOUNT, PASSWORD, PASSSALT, USERTYPE)
values ('6194c57c944a43799227fbf1632ed451', 'testuser2', 'testuser2', 'cd0dc83086dbea2d59c8d37ccfbd5a6033232132', '528555265a084841859782aa3a9dd9e1', '0');

insert into PLATFORM_USERS (ID, NAME, ACCOUNT, PASSWORD, PASSSALT, USERTYPE)
values ('8d0cd934a74744439d1679ebee060fbf', '����Ա', 'admin', 'ce819b306f3e11a1bdb2dfb69ff866865cf8bacf', 'f7c86d1196134e439791f8a3d0cf72bb', '0');

insert into PLATFORM_USERS (ID, NAME, ACCOUNT, PASSWORD, PASSSALT, USERTYPE)
values ('0c239c0ffc7949d2b07be1185a9e1a36', '��Ӣ��', 'dyj', '72b7ee22164d6ed84983a84b69d387d2b11603be', '955edd5f7d7743e89f67b025c6d59910', '0');

prompt Done.
