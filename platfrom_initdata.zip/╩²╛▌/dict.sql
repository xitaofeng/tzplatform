prompt Importing table PLATFORM_DICT...
set feedback off
set define off
insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb126', '440', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb129', '450', '�����˹��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb131', '458', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb132', '462', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb134', '470', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb135', '474', '�������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000207', '02', '����ίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000209', '04', '����ίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000215', '02', '������Ա', 'bzlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000217', '04', '�̸���Ա', 'bzlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000087', '2', '����֤', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000089', '4', '��ְ�ɲ�֤', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000091', '6', '�����������/����֤��', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000095', 'A', '����', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000097', '01', '�������źͼ����', 'xxbb', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000102', '02', '����������������Сѧ', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000104', '04', 'Сѧ��ѧ��', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000106', '06', '��ȫ��ѧ', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000108', '08', '������ѧ', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000112', '12', '��������һ������������ѧУ', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000114', '14', 'һ����ѧУ', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000116', '16', 'ְ��', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000118', '18', '����ְ�߲���', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000120', '01', '���Ƚ���', 'xxsx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000122', '03', '�е�ְҵѧУ', 'xxsx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000127', '01', '��������', 'xxzt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000129', '03', '�Ѿ�����', 'xxzt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000099', '03', '�������Ű�', 'xxbb', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000130', '04', '����', 'xxzt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000002', '02', '����', 'xd', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000004', '04', '�ڸ߰�', 'xd', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000136', '02', '���꼶', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000138', '04', '���꼶', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('0020219', '06', '���ν�ʦ', 'bzlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb2', '008', '����������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000141', '07', '��һ', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000146', '12', '����', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000148', '02', '���ư�', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000151', '05', '��������Сѧ��', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000154', '08', 'Сѧ�س��ࣨ�������ǵȰࣩ', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000155', '09', 'Сѧ�����м���', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000156', '10', 'Сѧ�����м���', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000157', '11', 'Сѧ�����м���', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000158', '12', '��ͨ���а�', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000160', '14', '���и�ʽ��', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000161', '15', '���н�ѧ���', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000162', '16', '�����س��ࣨ�������ǵȰࣩ', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000163', '17', '���������м���', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000164', '18', '���������м���', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000165', '19', '���������м���', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000167', '21', '����������а�', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000168', '22', '�����س��ࣨ�������ǵȰࣩ', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000169', '23', '����', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000170', '01', '��ͨѧ��', 'stuType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000171', '02', '���Ͷ�ѧ��', 'stuType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000173', '04', '���Բм�ѧ��', 'stuType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000174', '05', '�����м�ѧ��', 'stuType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000175', '06', '�����м�ѧ��', 'stuType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000176', '07', '֫��м�ѧ��', 'stuType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000177', '08', '�������Ͷ�ѧ��', 'stuType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000179', '02', '�߶�', 'jdfs', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000181', '04', '����', 'jdfs', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000184', '03', '����', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000186', '05', '����', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000189', '08', '��ʧ����', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000193', '05', '�೤', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000196', '08', '�жӳ�', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000005', '01', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000007', '03', '��ѧ', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000010', '06', 'Ʒ�������', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000015', '11', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000017', '13', '��ʷ', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000019', '15', '��ѧ', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000022', '18', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000024', '20', 'ͨ�ü���', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000028', '01', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000030', '03', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000033', '06', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000035', '08', '׳��', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000040', '13', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000042', '15', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000045', '18', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000047', '20', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000049', '22', '���', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000054', '27', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000057', '30', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000059', '32', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000061', '34', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000063', '36', 'ë����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000068', '41', '��������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000071', '44', '����˹��', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000073', '46', '�°���', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000075', '48', 'ԣ����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000080', '53', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000082', '55', '�����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000084', '98', '���Ѫͳ�й�����ʿ', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000200', '12', 'ѧ����ίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000202', '14', '��ί��ίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000219', 'z', '����', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('0020221', '08', '����', 'bzlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('0000234', '19', '����', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb4', '012', '����������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb6', '020', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb9', '031', '�����ݽ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb10', '032', '����͢', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb12', '040', '�µ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb13', '044', '�͹���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb15', '050', '�ϼ�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb17', '052', '�ͰͶ�˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb18', '056', '����ʱ', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb21', '068', '����ά��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('1476B9B1088B4EE0936551BD54A350CE', 'xtcslx', 'ϵͳ����gjkjj666358', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('7A812C75A51E445C8A411AF5CDFC8558', '001', '��������¼', 'xtcslx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000180', '03', '����', 'jdfs', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000182', '01', '������ѧ', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000183', '02', '���', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000185', '04', '����', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000187', '06', 'תѧ', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000188', '07', '��ѧ', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000190', '09', '��������', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000192', '11', '����', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000194', '06', 'С�ӳ�', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000195', '07', '�ж�ίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000197', '09', '���ίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000006', '02', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000008', '04', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000009', '05', '˼������', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000011', '07', 'Ӣ��', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000013', '09', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000014', '10', 'Ʒ��������', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000016', '12', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000018', '14', '˼��Ʒ��', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000020', '16', '��ѧ', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000021', '17', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000023', '19', '��Ϣ����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000025', '21', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000026', '22', '�����뽡��', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000198', '10', '��ӳ�', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000029', '02', '�ɹ���', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000031', '04', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000032', '05', 'ά�����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000034', '07', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000036', '09', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000038', '11', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000039', '12', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000041', '14', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000043', '16', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000044', '17', '��������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000046', '19', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000048', '21', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000050', '23', '��ɽ��', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000051', '24', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000053', '26', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000055', '28', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000056', '29', '�¶�������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000058', '31', '���Ӷ���', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000060', '33', 'Ǽ��', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000062', '35', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000064', '37', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000065', '38', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000067', '40', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000069', '42', 'ŭ��', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000070', '43', '���α����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000072', '45', '���¿���', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000074', '47', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000076', '49', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000077', '50', '��������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000079', '52', '���״���', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000081', '54', '�Ű���', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000083', '56', '��ŵ��', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000085', '99', '����', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000199', '11', 'У�����Ÿ�����', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000201', '13', 'ѧ������ϯ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000203', '15', '����֧ίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000205', '17', '��֧�����', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('0020220', '07', '���Σ�ְ����ʦ', 'bzlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000233', '18', '����֧���', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb3', '010', '�ϼ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb5', '016', '������Ħ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb8', '028', '����ϺͰͲ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb11', '036', '�Ĵ�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb14', '048', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb16', '051', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb19', '060', '��Ľ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('A75D60CD1BA1466383B3854F66577BDD', 'ABC', 'ABC', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('08B6B40456AA42C59FA6C7523F235C1B', '1', '1', '123', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('342430898F834BBAAF8131BDF4C2E9B6', '002', 'ϵͳlogo', 'xtcslx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('EF9B83E5DDC44B19B90861B55A3C44B9', '003', '��������', 'xtcslx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('19A8AF5A400D40D391B1F9B047B43A94', '004', 'Ŀ¼����', 'xtcslx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('4A8A98A5BDFD4A1E8D277AC527299ED8', '1111', '1111', '123', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('D67D50671BD2442C815B0A81E97F6349', 'gzby', '���б�ҵ', 'whcd', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('064FFC0ECA054FAB94A7735B2F0D9BF2', 'bk', '����', 'whcd', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('5915219C82934CF6BB4803BFC5D1C172', 'synchroType', '������Ӧ��ͬ���ӿ�', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb41', '144', '˹������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb49', '174', '��Ħ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb57', '196', '����·˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb70', '238', '������Ⱥ��������ά��˹��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb150', '530', '����������˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb164', '584', '���ܶ�Ⱥ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb176', '626', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb190', '678', 'ʥ��������������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb30', '096', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb75', '254', '����������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb83', '276', '�¹�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb91', '316', '�ص�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb101', '352', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb115', '408', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb127', '442', '¬ɭ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000212', '3', '��Ƹ��Ա', 'userType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000093', '8', '̨�����������½ͨ��֤', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000110', '10', '������������������ȫ��ѧ', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000124', '05', '�������ѧУ', 'xxsx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000133', '03', '����ѧ��', 'xqlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000144', '10', '��һ', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000153', '07', 'Сѧ��ѧ���', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000159', '13', '����������а�', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000166', '20', '��ͨ���а�', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000172', '03', '�����м�ѧ��', 'stuType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000178', '01', 'סУ', 'jdfs', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000191', '10', '�����У', 'stuSource', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000012', '08', '��ʷ�����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000027', '23', '����', 'teachcourse', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000037', '10', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000052', '25', 'ˮ��', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000066', '39', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000078', '51', '������', 'nation', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000204', '16', '��֧��ίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb7', '024', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb20', '064', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('28579817AED14C36807B06C921B5F1DD', '112 ', '�׶���˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('AA43FD3F06CE4F10974759DA6E16BE10', '01', '��ְ������', 'devlanguage', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('7557FA77DA7F49B994DF3FCDD510F248', '01', 'ѧ������', 'devlanguage', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('426B7E40F242484483422CD2AA20169E', 'test', '�ֵ����Ͳ���', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('78777821E0E74791BD9B44A97660D257', '01', '�����ֵ�01', 'test', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('584143F7B16A40CB8FC0C71B7D44EF02', '01', '�ֵ����01', 'test', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('F74E9CDC39574225AB69CFA289D3A33D', 'devlanguage', 'Ӧ����������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('73690C41B5254CD2B202097F5DFDE36C', 'java', '�οͷ���', 'devlanguage', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('799C08D3EE314E419584D027905570FB', 'php', 'ͳ�Ʒ���', 'devlanguage', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('8927C8E23E9D472694F66846C08B9EF9', 'mzdmb', '��������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('C4F91EDBB2CE47A5ACF622EA0F439A54', 'hanzu', '����', 'mzdmb', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('993D5247B1F746FC915FC48BD75758C6', '12313', '��������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('E409B637A8574C0690D94021A3BAAE7A', 'schoolNature', 'ѧУ����', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('5DD95CDBC2824DB3BD885FFB69D5AE60', 'classType', '�༶����', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('FEC25E6C06844D0584A3920C2E718895', 'stuType', 'ѧ�����', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('3FE367CC7B7D405AAE02F6FF2205C7E2', 'stuSource', 'ѧ����Դ', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('F358F2485F9047B4A7E15CA3EE3D882A', 'teachcourse', '�ν̿�Ŀ', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('D2A5C97098B0490C8E79C46DEB2083C0', 'idType', '֤������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('1255258B216D43D8A4892A87D3522044', 'userType', '�û���������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('089CC8C86BAC46B8BCFD52137B24806E', 'xszw', 'ѧ��ְ��', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('2255F4ED80A24C35A91400823E9CEFCD', 'bzlx', '��������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('39ECF4AEA5864B389673089E1ED5F845', 'xxbb', 'ѧУ���', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('A77D96CFED564F37B74E1D8DAC375569', 'xxzt', 'ѧУ״̬', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('0EC4DB78148E484E94E9E24F11D32420', 'xd', 'ѧ��', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('DB061867FB47420BBE84CED56D7A4D3D', 'nationality', '����', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('090059167B684C079383C0D636E384DC', 'xxsx', 'ѧУ����', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('03C03468515545D2B49B9132AB64EF70', 'nj', '�꼶', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('F3831BF6F0924A0D9C15603CAC87DEA0', 'jdfs', '�Ͷ���ʽ', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('7A78F7B40E1546E79B3F5EB452101C42', 'nation', '����', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('D835BB7E17854E73813CE55F4FE9D194', 'xqlx', 'ѧ������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('6DCCC57C71DB41B3A89E2537F57EDC8F', 'religion', '�ڽ�����', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('1AAF539827784283A08DF34816283F9F', 'mbwt', '�ܱ�����', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('458C126395DB44EDA40153891A109815', 'question1', '����ѧ�ţ��򹤺ţ��ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('CA858C8DB690404FA5C73BA544473EEB', 'question2', '��ĸ�׵������ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('DFD336D216F6457E9F65160A688AE3AA', 'question3', '��ĸ�׵������ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('F3569CCCC6F84D59BBFE2F9D4079263B', 'question4', '�����׵������ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('8C8242C7CCBA42EABCE39FCA714F1169', 'question5', '�����׵������ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('53EBB5D3195B42EBA6FBE86A7013231A', 'question6', '1111������Ϥ��ͯ����������ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('DCF72AA4CC7A4D50AEE1BE2667EE6033', 'question7', '������Ϥ��ѧУ�������������ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('FD48EC5650C4476A8AEB6C37E7908933', 'question8', '����Ӱ�������������ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('7D08336EA4364C38A57CE98D7923D1E2', 'question9', '����ϲ���������˶��ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('819941393E914721A29DF80A3666787A', 'question10', '��Сѧ�����ε������ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('11BAE9417D4149878C617652A1D4BF10', 'question11', '���Ͷ���Сѧ�����ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('59AF2F511184472BBB7A48D99749B953', 'question12', '���ĳ������ǣ�', 'mbwt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('989FAC6DE6AC446983557DD99702ABA3', '1', 'ѧ��', 'synchroType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('F444337BF06C4E4CAEB35DA42053EE9C', '2', '��ʦ', 'synchroType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('C7E9E0C76FDB44978E0231DDB1916621', '3', 'ѧУ', 'synchroType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('4C7EE4BB68BF476F94B0BE44F7BB7C99', '4', '����', 'synchroType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('638DD8D50C5246A981FC06EAE20B2454', '5', 'Ⱥ��', 'synchroType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('BAED1047EA114A7784BB306E66A90F25', '6', '��Ա', 'synchroType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('9b4a4cfd5ad9415ca51e7768e682b591', 'teacherdev', '��ʦ��չ', 'webappkind', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('3abb516d12c34ffebeb51fa9c4e0b1cf', 'studentdev', 'ѧ���ɳ�', 'webappkind', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('4851011774D14D498D741E7DF1427B09', 'whcd', '�Ļ��̶�', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('ce999e22683e4c2284370c113427c6fb', 'hotquestion', '��������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('25721f4edd544ee9ad33e8094cd0024e', 'systemroletype', 'ϵͳ��ɫ����', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('65df53e7421a4f3a84ea2cf6009358af', 'commonquestion', '��������', 'hotquestion', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('d8fc0ddb03df4255b0c8aaea4f7e9a32', 'loginquestion', '��¼ע��', 'hotquestion', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('aa694e69c25b45aba7bc459a5be4a5b7', 'apiquestion', 'API���', 'hotquestion', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('2686b3d4acc64cc4ab9d57464a61b5f2', 'dataquestion', '���ݷ���', 'hotquestion', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('e424afa246bb414e89d61785b9e57443', 'appquestion', 'Ӧ�����', 'hotquestion', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('b58d004c586d4a07914b73e3b467a9a3', 'otherquestion', '����', 'hotquestion', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('9cd48f1e316444708ac38d1c840a3966', 'webappkind', 'Ӧ�÷���', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('726b032d8f354dc89b8c211c0eb51fa4', 'edumanage', '��������', 'webappkind', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('b83e593c4f7e416b8c951f4b07ee0cbb', 'classroomteaching', '���ý�ѧ', 'webappkind', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('a71fdc1673614e51b3e6c7f5ebd9656d', 'interactivelearning', '����ѧϰ', 'webappkind', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('7677ae7363e44ef48797e1cbb503e150', 'otherapp', '����Ӧ��', 'webappkind', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('2289caf5e44e4985a27b9109fe3e2d54', 'lostFoundType', '�����������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('aa6ae47738a541938ebe1931ad9d3f8f', 'useCode', '����APPʹ��', 'lostfounttype', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('d3b4454ee5f54d3da79f544bcf002c19', 'code001', 'APPʹ�����', 'lostFoundType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('dc7e39ce5d3d45f693d9c66e6c44411b', 'campusSceneryType', 'У԰�������', 'typeroot', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('20e43779e0d04d4caa659ed2bf715611', 'code002', '�����Ż�', 'lostFoundType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('11714d833b244e69b76442e30a1c4df7', '0001', '�羰', 'campusSceneryType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('89f20ef621f244cdba7c8b3e18f57673', '00003', '����', 'campusSceneryType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('a1a8da1e7ef84c44a894105dd0054f1d', '321213211211111', '132131232112', '666', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('b276b3959c24447c87a2cc2dfeb95c78', 'channeladmin', '��Ŀ����Ա', 'systemroletype', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('f8b9f12df30c4883a38e39c4a20900ca', 'administrator', '��������Ա', 'systemroletype', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('529c2f688db945619539f7ad9bd40c76', 'commonuser', '��ͨ������', 'systemroletype', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('34c092f96f724627b66d7e9b081c4010', '23123', '2131', null, null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb34', '112', '�׶���˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb35', '116', '����կ', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb36', '120', '����¡', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb37', '124', '���ô�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb38', '132', '��ý�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb39', '136', '����Ⱥ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb40', '140', '�з�aghjfj', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb42', '148', 'է��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb43', '152', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb44', '156', '�й�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb45', '158', '̨��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb46', '162', 'ʥ����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb47', '166', '�ƿ�˹�����֣�Ⱥ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb48', '170', '���ױ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb50', '175', '��Լ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb51', '178', '�չ�������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb52', '180', '�չ�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb53', '184', '���Ⱥ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb54', '188', '��˹�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb55', '191', '���޵���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb56', '192', '�Ű�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb58', '203', '�ݿ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb59', '204', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb60', '208', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb62', '214', '�������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb64', '222', '�����߶�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb65', '226', '���������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb67', '232', '����������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb68', '233', '��ɳ����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('d1804eb2661c4339b5effa07d2d1561f', '00', '���', 'religion', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb137', '480', 'ë����˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb138', '484', 'ī����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb140', '496', '�ɹ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb142', '500', '����������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb143', '504', 'Ħ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb145', '512', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb146', '516', '���ױ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb148', '524', '�Ჴ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb151', '533', '��³��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb153', '548', '��Ŭ��ͼ', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb154', '554', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb156', '562', '���ն�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb157', '566', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb159', '574', 'ŵ���˵�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb161', '580', '����������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb162', '581', '����������С����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb165', '585', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb167', '591', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb168', '598', '�Ͳ����¼�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb170', '604', '��³', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb172', '612', 'Ƥ�ؿ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb173', '616', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb175', '624', '�����Ǳ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb178', '634', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb179', '638', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb181', '643', '����˹����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb183', '654', 'ʥ������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb184', '659', 'ʥ���ĺ���ά˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb186', '662', 'ʥ¬����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb187', '666', 'ʥƤ�������ܿ�¡', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb189', '674', 'ʥ����ŵ', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb192', '686', '���ڼӶ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb193', '690', '�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb195', '702', '�¼���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb22', '070', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb24', '074', '��ά��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb26', '084', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb27', '086', 'Ӣ��ӡ�������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb29', '092', 'Ӣ��ά����Ⱥ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb32', '104', '���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb196', '703', '˹�工��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb197', '704', 'Խ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb198', '705', '˹��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb199', '706', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb200', '710', '�Ϸ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb201', '716', '��Ͳ�Τ', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb202', '724', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb203', '732', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb204', '736', '�յ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb205', '740', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb206', '744', '˹�߶��͵��������ӵ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb207', '748', '˹��ʿ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb208', '752', '���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb209', '756', '��ʿ', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb210', '760', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb211', '762', '������˹̹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb212', '764', '̩��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb213', '768', '���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb214', '772', '�п���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb215', '776', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb216', '780', '�������Ͷ�͸�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb217', '784', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb218', '788', 'ͻ��˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb219', '792', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb220', '795', '������˹̹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb221', '796', '�ؿ�˹�Ϳ���˹Ⱥ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb222', '798', 'ͼ��¬', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb223', '800', '�ڸɴ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb224', '804', '�ڿ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb225', '807', '�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb226', '818', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb227', '826', 'Ӣ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb228', '834', '̹ɣ����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb229', '840', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb230', '850', '����ά����Ⱥ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb231', '854', '�����ɷ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb232', '858', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb233', '860', '���ȱ��˹̹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb234', '862', 'ί������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb235', '876', '����˹�͸�ͼ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb236', '882', '��Ħ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb237', '887', 'Ҳ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb238', '891', '��˹����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb239', '894', '�ޱ���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('fce6ba149658467d863db3cfe034c841', '00', '�׶�԰', 'xd', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000107', '07', '�߼���ѧ', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000109', '09', '����ѧУ������ѧ��', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000111', '11', '�������������������', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000113', '13', '�������������������', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000115', '15', 'Сѧ���и��в���', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000117', '17', 'ְ�ո߲���', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000119', '19', '����', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000121', '02', '��ͨ�е�ѧУ', 'xxsx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000123', '04', '����ѧУ', 'xxsx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000125', '06', '����', 'xxsx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000126', '07', '��������ѧУ', 'xxsx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000128', '02', '�н�����ѧ��', 'xxzt', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000098', '02', '���������', 'xxbb', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000100', '04', '����', 'xxbb', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000131', '01', '�＾ѧ��', 'xqlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000001', '01', 'Сѧ', 'xd', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000003', '03', '����', 'xd', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000132', '02', '�ļ�ѧ��', 'xqlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000134', '04', '����', 'xqlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000135', '01', 'һ�꼶', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000137', '03', '���꼶', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000139', '05', '���꼶', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000140', '06', '���꼶', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('562c147650d447359c2a554b48c53fb1', '004', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000142', '08', '����', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000143', '09', '����', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000145', '11', '�߶�', 'nj', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000147', '01', '�Ŀư�', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000149', '03', 'ʵ���', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000150', '04', '��ͨСѧ��', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000152', '06', 'Сѧ��ʽ��', 'classType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb61', '212', '�������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb63', '218', '��϶��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb66', '231', '����������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb69', '234', '����Ⱥ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb136', '478', 'ë��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb139', '492', 'Ħ�ɸ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb141', '498', 'Ħ������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb144', '508', 'Īɣ����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb147', '520', '�³', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb149', '528', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb152', '540', '�¿��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb155', '558', '�������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb158', '570', 'Ŧ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb160', '578', 'Ų��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb163', '583', '�ܿ�������������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb166', '586', '�ͻ�˹̹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb169', '600', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb171', '608', '���ɱ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb174', '620', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb177', '630', '�������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb180', '642', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb182', '646', '¬����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb185', '660', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb188', '670', 'ʥ��ɭ�غ͸����ɶ�˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb191', '682', 'ɳ�ذ�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb194', '694', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb23', '072', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb25', '076', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb28', '090', '������Ⱥ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb31', '100', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb33', '108', '��¡��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb98', '340', '�鶼��˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb100', '348', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb103', '360', 'ӡ��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb106', '372', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb109', '384', '���ص���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb111', '392', '�ձ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb114', '404', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb117', '414', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb119', '418', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb122', '428', '����ά��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb125', '438', '��֧��ʿ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb128', '446', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb130', '454', '����ά', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb133', '466', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000211', '1', 'ѧ��', 'userType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000206', '01', 'ѧϰίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000208', '03', '����ίԱ', 'xszw', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000210', '2', '��ʦ', 'userType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000213', '4', '����', 'userType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000214', '01', 'ר�ν�ʦ', 'bzlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000216', '03', '������Ա', 'bzlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000218', '05', 'У����ҵְ��', 'bzlx', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000088', '3', 'ʿ��֤', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000086', '1', '��������֤', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000090', '5', '����������֤', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000092', '7', '������������/����֤��', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000094', '9', '�������þ�ס֤', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000096', 'B', '���ڱ�', 'idType', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000101', '01', 'Сѧ', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000103', '03', 'һ����ѧУСѧ��', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('000105', '05', '����ѧУ����Сѧ��', 'schoolNature', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb71', '239', '�������ǵ�����ɣ��Τ�浺', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb72', '242', '쳼�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb73', '246', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb74', '250', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb76', '258', '��������������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb77', '260', '�����ϲ����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb78', '262', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb79', '266', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb80', '268', '��³����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb81', '270', '�Ա���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb82', '275', '�ͻ�˹̹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb84', '288', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb85', '292', 'ֱ������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb86', '296', '�����˹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb87', '300', 'ϣ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb88', '304', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb89', '308', '�����ɴ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb90', '312', '�ϵ�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb92', '320', 'Σ������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb93', '324', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb94', '328', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb95', '332', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb96', '334', '�յµ���������ɵ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb97', '336', '��ٸ�', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb99', '344', '���', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb102', '356', 'ӡ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb104', '364', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb105', '368', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb107', '376', '��ɫ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb108', '380', '�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb110', '388', '�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb112', '398', '������˹̹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb113', '400', 'Լ��', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb116', '410', '����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb118', '417', '������˹˹̹', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb120', '422', '�����', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb121', '426', '������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb123', '430', '��������', 'nationality', null);

insert into PLATFORM_DICT (ID, NAME, VALUE, TYPE, CREATETIME)
values ('561c147650d447359c2a554b48c53fb124', '434', '������', 'nationality', null);

prompt Done.
